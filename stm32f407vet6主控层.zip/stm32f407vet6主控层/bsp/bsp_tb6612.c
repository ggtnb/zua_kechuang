/*
 * ������������Ӳ�������������չ����Ӳ�����Ϲ���ȫ����Դ
 * �����������www.lckfb.com
 * ����֧�ֳ�פ��̳���κμ������⻶ӭ��ʱ����ѧϰ
 * ������̳��https://oshwhub.com/forum
 * ��עbilibili�˺ţ������������塿���������ǵ����¶�̬��
 * ��������׬Ǯ���������й�����ʦΪ����
 * 
 Change Logs:
 * Date           Author       Notes
 * 2024-03-22     LCKFB-LP    first version
 */
#include "bsp_tb6612.h"
#include "board.h"


/************************************************
�������� �� TB6612_Init
��    �� �� TB6612������ 
��    �� �� pre��ʱ��ʱ��Ԥ��Ƶֵ    per����
�� �� ֵ �� ��
��    �� �� LC  PWMƵ��=168 000 000 /( (pre+1) * (per+1) ) 
*************************************************/
void TB6612_Init(uint16_t pre,uint16_t per)
{
	GPIO_InitTypeDef 			GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  	TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  			TIM_OCInitStructure;
	
 
	RCC_APB1PeriphClockCmd(RCC_PWMA_TIMER,ENABLE);//ʹ�ܶ�ʱ��3ʱ��
 	RCC_AHB1PeriphClockCmd(RCC_PWMA,ENABLE);   	  //ʹ��GPIO����

 

	GPIO_InitStructure.GPIO_Pin = GPIO_PWMA; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;  
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(PORT_PWMA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_PWMB; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;  
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(PORT_PWMB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_PWMC; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;  
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(PORT_PWMC, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_PWMD; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;  
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(PORT_PWMD, &GPIO_InitStructure);
	
	GPIO_PinAFConfig(PORT_PWMA, GPIO_PWMA_SOURCE, AF_PWMA); 
	GPIO_PinAFConfig(PORT_PWMB, GPIO_PWMB_SOURCE, AF_PWMB);
	GPIO_PinAFConfig(PORT_PWMC, GPIO_PWMC_SOURCE, AF_PWMC);
	GPIO_PinAFConfig(PORT_PWMD, GPIO_PWMD_SOURCE, AF_PWMD);
 
   //��ʼ��TIM4
	TIM_TimeBaseStructure.TIM_Period = per;
	TIM_TimeBaseStructure.TIM_Prescaler =pre - 1; 
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; 
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  
	TIM_TimeBaseInit(BSP_PWMA_TIMER, &TIM_TimeBaseStructure);
	
	//��ʼ��TIM4 Channel2 PWMģʽ	 
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; 
	TIM_OC1Init(BSP_PWMA_TIMER, &TIM_OCInitStructure); 
	
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; 
	TIM_OC2Init(BSP_PWMA_TIMER, &TIM_OCInitStructure); 
	
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; 
	TIM_OC3Init(BSP_PWMA_TIMER, &TIM_OCInitStructure);
	
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; 
	TIM_OC4Init(BSP_PWMA_TIMER, &TIM_OCInitStructure);
	
	TIM_OC1PreloadConfig(BSP_PWMA_TIMER, TIM_OCPreload_Enable);  
	TIM_OC2PreloadConfig(BSP_PWMA_TIMER, TIM_OCPreload_Enable);  
	TIM_OC3PreloadConfig(BSP_PWMA_TIMER, TIM_OCPreload_Enable); 
	TIM_OC4PreloadConfig(BSP_PWMA_TIMER, TIM_OCPreload_Enable); 
	
	TIM_Cmd(BSP_PWMA_TIMER, ENABLE);  //ʹ��TIM4
	
	AIN_GPIO_INIT(); // ʹ��AIN��GPIO
	BIN_GPIO_INIT();
}

void AIN_GPIO_INIT(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AIN1, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_AIN1|GPIO_AIN2|GPIO_BIN1|GPIO_BIN2|GPIO_DIN1|GPIO_DIN2;

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(PORT_AIN2, &GPIO_InitStructure);
}

void BIN_GPIO_INIT(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AIN1, ENABLE);

	GPIO_InitStructure.GPIO_Pin =GPIO_CIN1|GPIO_CIN2;

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(PORT_AIN2, &GPIO_InitStructure);
}


void AO1_Control(uint8_t dir, uint32_t speed)
{
    if( dir == 1 )
    {
        AIN1_OUT(0);
        AIN2_OUT(1);
    }
    else
    {
        AIN1_OUT(1);
        AIN2_OUT(0);
    }   
    TIM_SetCompare1(BSP_PWMA_TIMER, speed );    
}

void AO2_Control(uint8_t dir, uint32_t speed)
{
    if( dir == 1 )
    {
        BIN1_OUT(1);
        BIN2_OUT(0);
    }
    else
    {
        BIN1_OUT(0);
        BIN2_OUT(1);
    }   
    TIM_SetCompare2(BSP_PWMA_TIMER, speed);    
}

void AO3_Control(uint8_t dir, uint32_t speed)
{
    if( dir == 1 )
    {
        GPIO_ResetBits(GPIOE,GPIO_CIN2);
        GPIO_SetBits(GPIOE,GPIO_CIN1);
    }
    else
    {
		GPIO_ResetBits(GPIOE,GPIO_CIN1);
        GPIO_SetBits(GPIOE,GPIO_CIN2);
    }   
    TIM_SetCompare3(BSP_PWMA_TIMER, speed );    
}

void AO4_Control(uint8_t dir, uint32_t speed)
{
    if( dir == 1 )
    {
        DIN1_OUT(1);
        DIN2_OUT(0);
    }
    else
    {
        DIN1_OUT(0);
        DIN2_OUT(1);
    }   
    TIM_SetCompare4(BSP_PWMA_TIMER, speed);    
}




