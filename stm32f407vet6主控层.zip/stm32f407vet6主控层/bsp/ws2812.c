#include "ws2812.h"
#include "board.h"
#include "stdio.h"
#include "math.h"


unsigned char LedsArray[WS2812_MAX * 3];      //������ɫ���ݴ洢����
unsigned int  ledsCount   = WS2812_NUMBERS;   //����ʵ�ʲʵ�Ĭ�ϸ���
unsigned int  nbLedsBytes = WS2812_NUMBERS*3; //����ʵ�ʲʵ���ɫ���ݸ���


void WS2812_GPIO_Init(void)
{
        GPIO_InitTypeDef  GPIO_InitStructure;
        RCC_AHB1PeriphClockCmd(RCC_DIN, ENABLE);

        GPIO_InitStructure.GPIO_Pin = GPIO_DIN;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN; // ����
        GPIO_Init(PORT_DIN, &GPIO_InitStructure);

        GPIO_ResetBits(PORT_DIN, GPIO_DIN);
}


void rgb_SetColor(unsigned char LedId, unsigned long color)
{
    if( LedId > ledsCount )
    {
        return;    //to avoid overflow
    }
    LedsArray[LedId * 3]     = (color>>8)&0xff;
    LedsArray[LedId * 3 + 1] = (color>>16)&0xff;
    LedsArray[LedId * 3 + 2] = (color>>0)&0xff;
}


void rgb_SetRGB(unsigned char LedId, unsigned long red, unsigned long green, unsigned long blue)
{
    unsigned long Color=red<<16|green<<8|blue;
    rgb_SetColor(LedId,Color);
}

void rgb_SendArray(void)
{
    unsigned int i;
    //��������
    for(i=0; i<nbLedsBytes; i++)
        Ws2812b_WriteByte(LedsArray[i]);
}


void RGB_LED_Reset(void)
{
        RGB_PIN_L();
        delay_us(281);
}


void Ws2812b_WriteByte(unsigned char byte)
{
    int i = 0, j = 0;
        for(i = 0; i < 8; i++ )
        {
                if( byte & (0x80 >> i) )//��ǰλΪ1
                {
                        RGB_PIN_H();
                        delay_us(1);//0.75us
                        RGB_PIN_L();
                        for(j = 0; j < 8; j++ );//0.25us
                }
                else//��ǰλΪ0
                {
                        RGB_PIN_H();
                        for(j = 0; j < 8; j++ );//0.25us
                        RGB_PIN_L();
                        delay_us(1);//0.833us
                }
        }
}