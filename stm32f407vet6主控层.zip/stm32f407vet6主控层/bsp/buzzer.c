#include "bsp_uart.h" 
#include "stdio.h"
#include <stdarg.h>
void buzzer_init(void)
{
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
	
	GPIO_InitTypeDef  GPIO_InitStructure;

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;

	GPIO_Init(GPIOB, &GPIO_InitStructure);
}
void buzzer_on(void)
{
	GPIO_ResetBits(GPIOB,GPIO_Pin_14);
}

void buzzer_off(void)
{
	GPIO_SetBits(GPIOB,GPIO_Pin_14);
}