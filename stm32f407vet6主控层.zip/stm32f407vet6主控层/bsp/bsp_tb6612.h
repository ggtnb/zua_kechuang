/*
 * ������������Ӳ�������������չ����Ӳ�����Ϲ���ȫ����Դ
 * �����������www.lckfb.com
 * ����֧�ֳ�פ��̳���κμ������⻶ӭ��ʱ����ѧϰ
 * ������̳��https://oshwhub.com/forum
 * ��עbilibili�˺ţ������������塿���������ǵ����¶�̬��
 * ��������׬Ǯ���������й�����ʦΪ����
 * 
 Change Logs:
 * Date           Author       Notes
 * 2024-03-22     LCKFB-LP    first version
 */

#ifndef _BSP_TB6612_H
#define _BSP_TB6612_H


#include "stm32f4xx.h"
#include "board.h"


#define RCC_AIN1                RCC_AHB1Periph_GPIOE
#define PORT_AIN1               GPIOE
#define GPIO_AIN1               GPIO_Pin_7

#define RCC_AIN2                RCC_AHB1Periph_GPIOE
#define PORT_AIN2               GPIOE
#define GPIO_AIN2               GPIO_Pin_8

#define RCC_PWMA                RCC_AHB1Periph_GPIOB
#define PORT_PWMA               GPIOB
#define GPIO_PWMA               GPIO_Pin_6
#define GPIO_PWMA_SOURCE		GPIO_PinSource6
#define AF_PWMA                 GPIO_AF_TIM4
  
#define RCC_BIN1               RCC_AHB1Periph_GPIOE
#define PORT_BIN1               GPIOE
#define GPIO_BIN1               GPIO_Pin_9

#define RCC_BIN2                RCC_AHB1Periph_GPIOE
#define PORT_BIN2               GPIOE
#define GPIO_BIN2               GPIO_Pin_10  
  
#define RCC_PWMB               RCC_AHB1Periph_GPIOB
#define PORT_PWMB               GPIOB
#define GPIO_PWMB               GPIO_Pin_7
#define GPIO_PWMB_SOURCE		GPIO_PinSource7
#define AF_PWMB                 GPIO_AF_TIM4

#define RCC_CIN1                RCC_AHB1Periph_GPIOE
#define PORT_CIN1               GPIOE
#define GPIO_CIN1               GPIO_Pin_11

#define RCC_CIN2                RCC_AHB1Periph_GPIOE
#define PORT_CIN2               GPIOE
#define GPIO_CIN2               GPIO_Pin_12

#define RCC_PWMC               	RCC_AHB1Periph_GPIOB
#define PORT_PWMC               GPIOB
#define GPIO_PWMC               GPIO_Pin_8
#define GPIO_PWMC_SOURCE		GPIO_PinSource8
#define AF_PWMC                 GPIO_AF_TIM4

#define RCC_DIN1                RCC_AHB1Periph_GPIOE
#define PORT_DIN1               GPIOE
#define GPIO_DIN1               GPIO_Pin_13

#define RCC_DIN2                RCC_AHB1Periph_GPIOE
#define PORT_DIN2               GPIOE
#define GPIO_DIN2               GPIO_Pin_14

#define RCC_PWMD              	RCC_AHB1Periph_GPIOB
#define PORT_PWMD               GPIOB
#define GPIO_PWMD               GPIO_Pin_9
#define GPIO_PWMD_SOURCE		GPIO_PinSource9
#define AF_PWMD                 GPIO_AF_TIM4

#define RCC_PWMA_TIMER          RCC_APB1Periph_TIM4
#define BSP_PWMA_TIMER          TIM4         		// ��ʱ��


#define AIN1_OUT(X)  GPIO_WriteBit(PORT_AIN1, GPIO_AIN1, X?Bit_SET:Bit_RESET)
#define AIN2_OUT(X)  GPIO_WriteBit(PORT_AIN2, GPIO_AIN2, X?Bit_SET:Bit_RESET)

#define BIN1_OUT(X)  GPIO_WriteBit(PORT_BIN1, GPIO_BIN1, X?Bit_SET:Bit_RESET)
#define BIN2_OUT(X)  GPIO_WriteBit(PORT_BIN2, GPIO_BIN2, X?Bit_SET:Bit_RESET)

#define CIN1_OUT(X)  GPIO_WriteBit(PORT_AIN1, GPIO_CIN1, X?Bit_SET:Bit_RESET)
#define CIN2_OUT(X)  GPIO_WriteBit(PORT_AIN2, GPIO_CIN2, X?Bit_SET:Bit_RESET)

#define DIN1_OUT(X)  GPIO_WriteBit(PORT_BIN1, GPIO_DIN1, X?Bit_SET:Bit_RESET)
#define DIN2_OUT(X)  GPIO_WriteBit(PORT_BIN2, GPIO_DIN2, X?Bit_SET:Bit_RESET)


void AIN_GPIO_INIT(void);
void BIN_GPIO_INIT(void);
void TB6612_Init(uint16_t pre,uint16_t per);
void AO1_Control(uint8_t dir, uint32_t speed);
void AO2_Control(uint8_t dir, uint32_t speed);
void AO3_Control(uint8_t dir, uint32_t speed);
void AO4_Control(uint8_t dir, uint32_t speed);	

#endif  /* _BSP_TB6612_H */
