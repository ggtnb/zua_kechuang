
#include "board.h"
#include "bsp_uart.h"
#include <stdio.h>
#include "bsp_tb6612.h"
#include "buzzer.h"
#include "oled.h"
#include "ws2812.h"
#include "k230_uart.h"
#include "duoji.h"
uint16_t rxdata;
uint16_t k230_rxdata;
uint16_t pwm_speed=100;
#define LED_COUNT 144
#define ACTIVE_LEDS 16
uint8_t Co = 100;
uint8_t flag=0;
#define base_speed 1000
#define base_pian_speed 820
#define pian_speed 370  
unsigned int colors[]={RED,GREEN,BLUE,WHITE};

void allLEDsSingleColor(uint32_t color) {
    for (uint16_t i = 0; i < LED_COUNT; i++) {
        rgb_SetColor(i, color);
    }
    rgb_SendArray();
}

int main(void)
{
	int i=0;
	SG90_Init();
	WS2812_GPIO_Init();
	buzzer_init();
	buzzer_off();
	board_init();
	uart1_init(115200U);
	uint16_t startPos = 0;
	TB6612_Init(168,1000);
	k230_uart_init(115200);
	while(1) 
	{	
		if(flag)
		{
			allLEDsSingleColor(WHITE);    // ȫ����ɫ
			delay_ms(300);
			allLEDsSingleColor(WHITE );  // ȫ����ɫ
			delay_ms(300);
			allLEDsSingleColor(WHITE);   // ȫ����ɫ
			delay_ms(300);
		}
		else
		{
			allLEDsSingleColor(RED);    // ȫ����ɫ
			delay_ms(300);
			allLEDsSingleColor(RED );  // ȫ����ɫ
			delay_ms(300);
			allLEDsSingleColor(RED);   // ȫ����ɫ
			delay_ms(300);
		}

		

//		if(flag)
//		{
//				for (uint16_t i = 0; i < LED_COUNT; i++) {
//            rgb_SetColor(i, BLACK);
//			}
//        
//			// 2. ������ǰ4��λ�õ�LED
//			for (uint8_t j = 0; j < ACTIVE_LEDS; j++) {
//				uint16_t pos = (startPos + j) % LED_COUNT;
//				rgb_SetColor(pos, colors[j]);
//			}
//			
//			// 3. �������ݵ�LED
//			rgb_SendArray();
//			
//			// 4. ������ʼλ��
//			startPos = (startPos + 1) % LED_COUNT;
//			
//			// 5. ������ˮ�ٶ�
//			delay_ms(20);
//		}
	}
	
 
}

void USART3_IRQHandler(void)//��������
{
	if(USART_GetITStatus(USART3, USART_IT_RXNE) == SET)//�ж��ǲ���������жϷ���
	{
		rxdata=USART_ReceiveData(USART3);
		
		switch(rxdata)
		{
			case 0x01://ǰ��
					AO1_Control(0, pwm_speed);
					AO2_Control(0,pwm_speed);
					AO3_Control(0,pwm_speed); 
					AO4_Control(0,pwm_speed);   
				break;
			case 0xff://ֹͣ
					AO1_Control(0, 0);
					AO2_Control(0,0);
					AO3_Control(0,0);
					AO4_Control(0,0);   
				break;
			case 0x03://����
					AO1_Control(0, 0);
					AO2_Control(0,0);
					AO3_Control(0,0);
					AO4_Control(0,0);  
				pwm_speed+=100;
				if(pwm_speed>1000)
				{
					pwm_speed=0;
				}
			case 0x02://����
					AO1_Control(1, pwm_speed);
					AO2_Control(1,pwm_speed);
					AO3_Control(1,pwm_speed); 
					AO4_Control(1,pwm_speed); 
				break;
			case 0x04://ԭ��ת
					AO1_Control(0, pwm_speed);
					AO2_Control(0,pwm_speed);
					AO3_Control(1,pwm_speed); 
					AO4_Control(1,pwm_speed); 
				break;
			case 0x06://��ת
					AO1_Control(0, pwm_speed);
					AO2_Control(0,pwm_speed);
					AO3_Control(0,pwm_speed/2); 
					AO4_Control(0,pwm_speed/2); 
				break;
			case 0x05://��ת
					AO1_Control(0, pwm_speed/2);
					AO2_Control(0,pwm_speed/2);
					AO3_Control(0,pwm_speed); 
					AO4_Control(0,pwm_speed); 
				break;
			case 0x07://������on
				buzzer_on();
				break;
			case 0x11://������off
				buzzer_off();
				break;
			case 0xc1://�ƴ���
				flag=1;
				break;
			case 0xc2://�ƴ���
				flag=0;
				break; 
		}
		USART_ClearITPendingBit(USART3, USART_IT_RXNE); //�Ѿ������������־λ 
	}  
}

void USART2_IRQHandler(void)
{
	if(USART_GetITStatus(USART2, USART_IT_RXNE) == SET)//�ж��ǲ���������жϷ���
	{
			k230_rxdata=USART_ReceiveData(USART2);
		switch(k230_rxdata) 
		{
			case 0x02:
					AO1_Control(0, base_speed);
					AO2_Control(0,base_speed);
					AO3_Control(0,base_speed); 
					AO4_Control(0,base_speed); 
				break;
			case 0x04:
					AO1_Control(0, pian_speed);
					AO2_Control(0,pian_speed);
					AO3_Control(0,base_pian_speed); 
					AO4_Control(0,base_pian_speed); 
				break;
			case 0x05:
					AO1_Control(0, base_pian_speed);
					AO2_Control(0,base_pian_speed);
					AO3_Control(0,pian_speed); 
					AO4_Control(0,pian_speed); 
				break; 
			case 0xff:
					AO1_Control(0, 0);
					AO2_Control(0,0);
					AO3_Control(0,0); 
					AO4_Control(0,0); 
				break;
			case 0x07:
				flag=1;
				break;
			case 0xa1:
				flag=0;
				break;
			case 0x11:
				buzzer_on();
				break;
			case 0x12:
				buzzer_off();
				break;
		}
		USART_ClearITPendingBit(USART2, USART_IT_RXNE); //�Ѿ������������־λ 
	}  
}

